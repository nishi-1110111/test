print_modname() {
  ui_print "******************************"
  ui_print " $MODNAME"
  ui_print " by $MODauthor "
  ui_print "******************************"
  ui_print " $MODdescription "
  ui_print "******************************"
}

on_install() {
  ui_print "- Releasing files"
}

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
  
}
